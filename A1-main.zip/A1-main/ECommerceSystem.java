import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.Scanner;

/*
 * Models a simple ECommerce system. Keeps track of products for sale, registered customers, product orders and
 * orders that have been shipped to a customer
 */
public class ECommerceSystem
{
    private ArrayList<Product>  products = new ArrayList<Product>();
    private ArrayList<Customer> customers = new ArrayList<Customer>();

    private ArrayList<ProductOrder> orders   = new ArrayList<ProductOrder>();
    private ArrayList<ProductOrder> shippedOrders   = new ArrayList<ProductOrder>();

    // These variables are used to generate order numbers, customer id's, product id's 
    private int orderNumber = 500;
    private int customerId = 900;
    private int productId = 700;

    private String orderType = "";

    // General variable used to store an error message when something is invalid (e.g. customer id does not exist)  
    String errMsg = null;

    // Random number generator
    Random random = new Random();

    public ECommerceSystem()
    {
        // NOTE: do not modify or add to these objects!! - the TAs will use for testing
        // If you do the class Shoes bonus, you may add shoe products

        // Create some products. Notice how generateProductId() method is used
        products.add(new Product("Acer Laptop", generateProductId(), 989.0, 99, Product.Category.COMPUTERS));
        products.add(new Product("Apex Desk", generateProductId(), 1378.0, 12, Product.Category.FURNITURE));
        products.add(new Book("Book", generateProductId(), 45.0, 4, 2, "Ahm Gonna Make You Learn", "T. McInerney", 1989));
        products.add(new Product("DadBod Jeans", generateProductId(), 24.0, 50, Product.Category.CLOTHING));
        products.add(new Product("Polo High Socks", generateProductId(), 5.0, 199, Product.Category.CLOTHING));
        products.add(new Product("Tightie Whities", generateProductId(), 15.0, 99, Product.Category.CLOTHING));
        products.add(new Book("Book", generateProductId(), 35.0, 4, 2, "How to Fool Your Prof", "D. Umbast", 1999));
        products.add(new Book("Book", generateProductId(), 45.0, 4, 2, "How to Escape from Prison", "A. Fugitive", 2003));
        products.add(new Book("Book", generateProductId(), 44.0, 14, 12, "Ahm Gonna Make You Learn More", "T. McInerney", 2000));
        products.add(new Product("Rock Hammer", generateProductId(), 10.0, 22, Product.Category.GENERAL));
        products.add(new Shoes("Yeezy", generateProductId(), 588.0, generateShoeStock()));
        products.add(new Shoes("Nike", generateProductId(), 65.0, generateShoeStock()));
        products.add(new Shoes("Addidas", generateProductId(), 88.0, generateShoeStock()));

        // Create some customers. Notice how generateCustomerId() method is used
        customers.add(new Customer(generateCustomerId(),"Inigo Montoya", "1 SwordMaker Lane, Florin"));
        customers.add(new Customer(generateCustomerId(),"Prince Humperdinck", "The Castle, Florin"));
        customers.add(new Customer(generateCustomerId(),"Andy Dufresne", "Shawshank Prison, Maine"));
        customers.add(new Customer(generateCustomerId(),"Ferris Bueller", "4160 Country Club Drive, Long Beach"));
    }

    /*
     * This method will increment order number
     */
    private String generateOrderNumber()
    {
        return "" + orderNumber++;
    }

    /*
     * This method will increment customer id
     */
    private String generateCustomerId()
    {
        return "" + customerId++;
    }

    /*
     * This method will increment product id
     */
    private String generateProductId()
    {
        return "" + productId++;
    }

    /*
     * This method will return error message
     */
    public String getErrorMessage()
    {
        return errMsg;
    }

    /*
     * This method will set order type
     * @param String type;
     */
    public void setType(String Type) { orderType = Type;}

    /*
     * This method will generate shoe stock
     */
    private int[][] generateShoeStock()
    {
        Random random = new Random();

        int[][] shoe_stock = new int[5][5];

        // Loop through the possible number of colours
        for (int x = 0; x < shoe_stock.length; x++){

            // loop through the possible sizes
            for (int y = x; y < shoe_stock[x].length; y++){

                // Generate random shoe stock
                shoe_stock[x][y] = random.nextInt((99 - 1) + 1) + 1;
            }
        }

        return shoe_stock;
    }

    /*
     * This method will print all products
     */
    public void printAllProducts()
    {
        for (Product p : products)
            p.print();
    }

    /*
     * This method will print all products that are books
     */
    public void printAllBooks()
    {
        for (Product p: products){
            if (p.getClass() == Book.class){
                p.print();
            }

        }
    }

    /*
     * This method will print all current orders
     */
    public void printAllOrders()
    {
        for (ProductOrder o :orders){
            o.print();
        }
    }

    /*
     * This method will print all shipped orders
     */
    public void printAllShippedOrders()
    {
        for (ProductOrder o :shippedOrders){
            o.print();
        }
    }

    /*
     * This method will print all customers
     */
    public void printCustomers()
    {
        for (Customer c : customers){
            c.print();
        }
    }

    /*
     * Given a customer id, print all the current orders and shipped orders for them (if any)
     * @param String customerId
     */
    public boolean printOrderHistory(String customerId)
    {
        boolean found = false;

        // Check to see if customer is in customer arraylist
        for (Customer c : customers){

            // if customer id equals customer id entered, return true
            if (c.getId().equals(customerId)){

                found = true;
                break;

            }
        }

        // if Customer not found, return false
        if (!found){

            errMsg = "Customer not found";

            return false;

        } else {
            // Print current orders of this customer
            System.out.println("Current Orders of Customer " + customerId);

            for (ProductOrder o: orders){

                if (o.getCustomer().getId().equals(customerId)){

                    o.print();

                }

            }
            // Print shipped orders of this customer
            System.out.println("\nShipped Orders of Customer " + customerId);

            for (ProductOrder o: shippedOrders){

                if (o.getCustomer().getId().equals(customerId)){

                    o.print();

                }

            }

            return true;

        }

    }

    /*
     * Order product method
     * @param String productId
     * @param String customerId
     * @param String productOptions
     */
    public String orderProduct(String productId, String customerId, String productOptions)
    {

        boolean c_in_system = false;
        boolean p_in_system = false;
        Customer customer_object = null;
        Product product_object = null;

        // Check to see if customer object is in customer object array list
        for (Customer x: customers){

            //if customer id equals given id, return true
            if (x.getId().equals(customerId)){

                c_in_system = true;

                customer_object = x;

            }

        }

        // if customer not in system, return false
        if (c_in_system == false){

            errMsg = ("Customer " + customerId + " Not Found");

            return null;

        }

        // Check to see if product object in product object array list
        for (Product p: products){

            // if object id equals given id, return true
            if (p.getId().equals(productId)){

                p_in_system = true;

                product_object = p;

            }

        }

        // if product not in system, return false
        if (p_in_system == false){

            errMsg = ("Product " + productId + " Not Found");

            return null;

        }

        // Check to see if anything is in product Options
        if (!productOptions.equals("")){

            // Check to see if product object is class Book
            if (product_object.getClass() == Book.class){

                // if Product options are valid
                if (product_object.validOptions(productOptions) == true){

                    // Check to see if there is stock for product option
                    if (product_object.getStockCount(productOptions) <= 0 ){

                        errMsg = productOptions + " has no more stock";
                        return null;

                        // reduce stock
                    } else {

                        product_object.reduceStockCount(productOptions);

                    }

                    // Error message (Invalid product option)
                } else {

                    errMsg = "Product Book ProductID " + product_object.getId() + " Invalid Options: " + productOptions;
                    return null;

                }

                // If product object is class shoe
            } else if (product_object.getClass() == Shoes.class) {

                // Split product options
                String[] options = productOptions.split(" ");

                String size = options[0];
                String colour = options[1];

                // Check to see if size is valid
                if (product_object.validOptions(size)) {

                    // Check to see if colour is valid
                    if (product_object.validOptions(colour)) {

                        // Check to see if there is stock for product option
                        if (product_object.getStockCount(productOptions) <= 0) {

                            errMsg = productOptions + " has no more stock";
                            return null;

                            // reduce stock
                        } else {

                            product_object.reduceStockCount(productOptions);

                        }

                        // Error Message (Invalid colour)
                    } else {
                        errMsg = "Product Shoe ProductID " + product_object.getId() + " Invalid Colour: " + colour;

                        return null;
                    }

                    // Error Message (Invalid size)
                } else {

                    errMsg = "Product Shoe ProductID " + product_object.getId() + " Invalid Size: " + size;

                    return null;
                }

                // Product ordered is not shoe or book
            } else {

                if (orderType.equals("Book")){

                    errMsg = "Product " + productId + " is not a book";
                    return null;

                } else {

                    errMsg = "Product " + productId + " is not a shoe";
                    return null;
                }

            }

            // Reduce stock
        } else {

            // Check to see if the ordered product is a book
            if (product_object.getClass() == Book.class) {

                errMsg = "Product " + productId + " is a book (use command 'Orderbook')";

                return null;

            // Check to see if ordered product is a shoe
            } else if (product_object.getClass() == Shoes.class) {

                errMsg = "Product " + productId + " is a shoe (use command 'Ordershoes')";

                return null;

            // Reduce product
            } else {

                product_object.reduceStockCount(productOptions);

            }

        }

        // Check if the product has stock available (i.e. not 0)
        // See class Product and class Book for the method getStockCount()
        // If no stock available, set errMsg string and return null

        // Create a ProductOrder, (make use of generateOrderNumber() method above)
        // reduce stock count of product by 1 (see class Product and class Book)
        // Add to orders list and return order number string
        String orderNumber = generateOrderNumber();

        orders.add(new ProductOrder(orderNumber, product_object, customer_object, productOptions));

        return "Order #" + orderNumber;
    }

    /*
     * Create a new Customer object and add it to the list of customers
     * @param String name
     * @param String address
     */
    public boolean createCustomer(String name, String address)
    {

        // check to see if customer name is valid
        if (name.equals("") || name.equals(null)){

            errMsg = "Invalid customer name";

            return false;

        // Check to see if address is valid
        } else if (address.equals("") || address.equals(null)) {

            errMsg = "Invalid customer address";

            return false;

        } else {

            // Create a Customer object and add to array list
            customers.add(new Customer(generateCustomerId(),name, address));

            return true;
        }
    }

    /*
     * Ship product with given order nu,ber
     * @param String orderNumber
     */
    public ProductOrder shipOrder(String orderNumber)
    {
        int location = 0;

        boolean found = false;

        // Loop through all orders
        for (int x =0; x < orders.size(); x++){

            // Check to see if order number equals given order number
            if (orders.get(x).getOrderNumber().equals(orderNumber)){

                location = x;

                orders.get(x).print();

                found = true;

                break;

            }
        }

        // If product has shipped, remove from order list, and move to shipped
        if (found){

            ProductOrder removed = orders.get(location);

            shippedOrders.add(removed);

            orders.remove(location);

            return removed;

        // Error message (Order number not valid)
        } else {

            errMsg = "Order number: " + orderNumber + " Not Found.";

            return null;

        }

    }

    /*
     * Cancel a specific order based on order number
     * @param String orderNumber
     */
    public boolean cancelOrder(String orderNumber)
    {
        int location = 0;

        boolean found = false;

        // Loop through orders list
        for (int x =0; x < orders.size(); x++){

            // If order found, found = true
            if (orders.get(x).getOrderNumber().equals(orderNumber)){

                location = x;

                found = true;

                break;

            }

        }

        // If found, remove order from orderlist
        if (found){

            ProductOrder removed = orders.get(location);

            orders.remove(location);

            return true;

        // Error Message (Order number not found)
        } else {

            errMsg = "Order " + orderNumber + " not found.";

            return false;

        }

    }

    /*
     * Print stock of product
     * @param String productId
     */
    public void getStock(String productId)
    {
        boolean p_in_system = false;

        Product product_object = null;

        // Check to see if product is in products list
        for (Product p: products){

            if (p.getId().equals(productId)){

                p_in_system = true;

                product_object = p;

            }

        }

        // Error Message (Product not found)
        if (p_in_system == false){

            errMsg = ("Product " + productId + " Not Found");

            System.out.println(errMsg);

        } else {

            // Check class of product, then print
            if (product_object.getClass() == Book.class) {

                System.out.println("Paperback: " + product_object.getStockCount("Paperback") + "Hardcover: " + product_object.getStockCount("Hardcover"));

            } else if (product_object.getClass() == Shoes.class) {

                System.out.println("Black: " + product_object.getArray("Black") + "Brown: " + product_object.getArray("Brown"));

            } else {

                System.out.println(product_object.getStockCount(""));

            }
        }
        
    }

    /*
     * Print authors who have books
     */
    public void printAuthors(){

        ArrayList<String> Authors = new ArrayList<String>();

        // Loop through products, find book class objects
        for (Product x : products){

            if (x.getClass() == Book.class){

                // check if author has already been added
                for (String y : Authors){

                    if (x.getAuthor().equals(y)){

                        break;

                    }

                }

                // Add to authors list
                Authors.add(x.getAuthor());
            }

        }
        
        for (String x : Authors){System.out.println(x);}
    }

    /*
     * Print books by author in increasing order
     * @param String Name
     */
    public boolean sortByAuthor(String Name) {

        ArrayList<Product> booksByAuthor = new ArrayList<Product>();

        // Check to see if book in products list was made by author given
        for (Product x: products) {

            if (x.getClass() == Book.class) {

                if (x.getAuthor().equals(Name)){

                    booksByAuthor.add(x);

                }

            }

        }

        // if total books made is greater than 1
        if (booksByAuthor.size() >= 1){

            // Sort books by author by published year
            Collections.sort(booksByAuthor, new Comparator<Product>(){

                @Override
                public int compare(Product A, Product B){

                    if (A.getYear() > B.getYear()){

                        return -1;

                    } else if (A.getYear() < B.getYear()){

                        return 1;

                    } else {

                        return 0;

                    }
                    
                }

            });

            // print
            for (Product x : booksByAuthor){x.print();}

            return true;

        // Error (Author is not found)
        } else {

            errMsg = "Author " + Name + " not found";

            return false;

        }

    }

    /*
     * Sort products by price
     */
    public void sortByPrice()
    {
        Collections.sort(products);
    }


    /*
     * Sort products by name
     */
    public void sortByName()
    {
        // Sort products
        Collections.sort(products, new Comparator<Product>(){

            @Override
            public int compare(Product A, Product B){
                return A.getName().compareTo(B.getName());
            }

        });
    }


    /*
     * Sort customers by name
     */
    public void sortCustomersByName()
    {
        // Sort customers
        Collections.sort(customers, new Comparator<Customer>(){

            @Override
            public int compare(Customer A, Customer B){
                return A.getName().compareTo(B.getName());
            }

        });
    }
}
